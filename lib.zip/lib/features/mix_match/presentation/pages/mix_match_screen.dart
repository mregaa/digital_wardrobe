import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/mix_match_provider.dart';
import '../../../wardrobe/domain/entities/outfit_item.dart';

/// Avatar Outfit Builder - Drag & drop outfits onto an avatar
class MixMatchScreen extends StatefulWidget {
  const MixMatchScreen({super.key});

  @override
  State<MixMatchScreen> createState() => _MixMatchScreenState();
}

class _MixMatchScreenState extends State<MixMatchScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<MixMatchProvider>().loadOutfits();
    });
  }

  void _showSaveDialog() {
    final nameController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Save Outfit Combo'),
        content: TextField(
          controller: nameController,
          decoration: const InputDecoration(
            labelText: 'Combo Name',
            hintText: 'e.g., "Summer Casual"',
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              if (nameController.text.isNotEmpty) {
                context.read<MixMatchProvider>().saveCombo(nameController.text);
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Combo saved!')),
                );
              }
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showSavedCombos() {
    final provider = context.read<MixMatchProvider>();
    
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Consumer<MixMatchProvider>(
        builder: (context, provider, _) {
          if (provider.savedCombos.isEmpty) {
            return Padding(
              padding: const EdgeInsets.all(32.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.bookmark_border, size: 48, color: Colors.grey[400]),
                  const SizedBox(height: 16),
                  Text(
                    'No saved combos yet',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Create an outfit and tap Save to store it here',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Colors.grey,
                        ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            );
          }

          return ListView(
            padding: const EdgeInsets.all(16),
            shrinkWrap: true,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(
                  'Saved Outfits',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
              ),
              ...provider.savedCombos.map((combo) {
                final itemCount = combo.equippedItems.values.whereType<Object>().length;
                return ListTile(
                  leading: const Icon(Icons.bookmark),
                  title: Text(combo.name),
                  subtitle: Text('$itemCount items'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () {
                          provider.deleteCombo(combo.id);
                        },
                      ),
                    ],
                  ),
                  onTap: () {
                    provider.loadCombo(combo);
                    Navigator.pop(context);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Loaded ${combo.name}')),
                      );
                    },
                  );
                }).toList(),
              ],
            );
          },
        ),
      );
    }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Avatar Outfit Builder'),
        actions: [
          IconButton(
            icon: const Icon(Icons.bookmark_outline),
            onPressed: _showSavedCombos,
            tooltip: 'Saved Combos',
          ),
        ],
      ),
      body: Consumer<MixMatchProvider>(
        builder: (context, provider, _) {
          if (provider.isLoading) {
            return const Center(child: CircularProgressIndicator());
          }

          if (provider.allOutfits.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.checkroom_outlined, size: 80, color: Colors.grey[400]),
                  const SizedBox(height: 16),
                  Text(
                    'No outfits in your wardrobe',
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Add some outfits to start building combos!',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Colors.grey,
                        ),
                  ),
                ],
              ),
            );
          }

          return Column(
            children: [
              // Avatar Canvas Area
              Expanded(
                flex: 3,
                child: Container(
                  color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.3),
                  child: Column(
                    children: [
                      // Style Hint
                      Container(
                        margin: const EdgeInsets.all(16),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        decoration: BoxDecoration(
                          color: Theme.of(context).colorScheme.primaryContainer,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.lightbulb_outline, size: 20),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Text(
                                provider.styleHint,
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ),
                          ],
                        ),
                      ),
                      // Avatar with slots
                      Expanded(
                        child: Center(
                          child: _buildAvatarCanvas(context, provider),
                        ),
                      ),
                      // Action buttons
                      Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            OutlinedButton.icon(
                              onPressed: provider.hasEquippedItems
                                  ? () => provider.clearAll()
                                  : null,
                              icon: const Icon(Icons.clear_all),
                              label: const Text('Clear All'),
                            ),
                            ElevatedButton.icon(
                              onPressed: provider.hasEquippedItems
                                  ? _showSaveDialog
                                  : null,
                              icon: const Icon(Icons.save),
                              label: const Text('Save Combo'),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              
              // Item Library Area
              Expanded(
                flex: 2,
                child: Container(
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surface,
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.1),
                        blurRadius: 8,
                        offset: const Offset(0, -2),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      // Category selector
                      _buildCategorySelector(context, provider),
                      // Item grid
                      Expanded(
                        child: _buildItemLibrary(context, provider),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildAvatarCanvas(BuildContext context, MixMatchProvider provider) {
    return Container(
      width: 280,
      height: 400,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey[300]!, width: 2),
      ),
      child: Stack(
        children: [
          // Avatar silhouette background
          Center(
            child: Icon(
              Icons.person_outline,
              size: 180,
              color: Colors.grey[200],
            ),
          ),
          // Outerwear slot (top layer)
          _buildSlot(context, provider, 'outerwear', 20, 80, 240, 140),
          // Top slot
          _buildSlot(context, provider, 'tops', 40, 100, 200, 120),
          // Bottom slot
          _buildSlot(context, provider, 'bottoms', 50, 220, 180, 120),
          // Shoes slot
          _buildSlot(context, provider, 'shoes', 80, 320, 120, 70),
          // Accessories slot (right side)
          Positioned(
            right: 10,
            top: 60,
            child: _buildAccessorySlot(context, provider),
          ),
        ],
      ),
    );
  }

  Widget _buildSlot(
    BuildContext context,
    MixMatchProvider provider,
    String category,
    double left,
    double top,
    double width,
    double height,
  ) {
    final equippedItem = provider.getEquippedItem(category);

    return Positioned(
      left: left,
      top: top,
      width: width,
      height: height,
      child: DragTarget<OutfitItem>(
        onWillAccept: (item) => item?.category.toLowerCase() == category,
        onAccept: (item) {
          provider.equipItem(item);
        },
        builder: (context, candidateData, rejectedData) {
          final isHovering = candidateData.isNotEmpty;

          return GestureDetector(
            onTap: equippedItem != null
                ? () => _showSlotActions(context, provider, category)
                : null,
            child: Container(
              decoration: BoxDecoration(
                color: isHovering
                    ? Theme.of(context).colorScheme.primary.withOpacity(0.2)
                    : equippedItem != null
                        ? Colors.transparent
                        : Colors.grey[200]?.withOpacity(0.5),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isHovering
                      ? Theme.of(context).colorScheme.primary
                      : Colors.grey[400]!,
                  width: isHovering ? 2 : 1,
                  style: equippedItem != null ? BorderStyle.none : BorderStyle.solid,
                ),
              ),
              child: equippedItem != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: equippedItem.imageUrl != null
                          ? Image.network(
                              equippedItem.imageUrl!,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Center(
                                child: Text(
                                  category.toUpperCase(),
                                  style: const TextStyle(fontSize: 10),
                                ),
                              ),
                            )
                          : Center(
                              child: Text(
                                category.toUpperCase(),
                                style: const TextStyle(fontSize: 10),
                                textAlign: TextAlign.center,
                              ),
                            ),
                    )
                  : Center(
                      child: Text(
                        category.toUpperCase(),
                        style: TextStyle(
                          fontSize: 10,
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildAccessorySlot(BuildContext context, MixMatchProvider provider) {
    final equippedItem = provider.getEquippedItem('accessories');

    return DragTarget<OutfitItem>(
      onWillAccept: (item) => item?.category.toLowerCase() == 'accessories',
      onAccept: (item) => provider.equipItem(item),
      builder: (context, candidateData, rejectedData) {
        final isHovering = candidateData.isNotEmpty;

        return GestureDetector(
          onTap: equippedItem != null
              ? () => _showSlotActions(context, provider, 'accessories')
              : null,
          child: Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: isHovering
                  ? Theme.of(context).colorScheme.primary.withOpacity(0.2)
                  : equippedItem != null
                      ? Colors.transparent
                      : Colors.grey[200]?.withOpacity(0.5),
              shape: BoxShape.circle,
              border: Border.all(
                color: isHovering
                    ? Theme.of(context).colorScheme.primary
                    : Colors.grey[400]!,
                width: isHovering ? 2 : 1,
              ),
            ),
            child: equippedItem != null
                ? ClipOval(
                    child: equippedItem.imageUrl != null
                        ? Image.network(
                            equippedItem.imageUrl!,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => const Icon(Icons.watch, size: 24),
                          )
                        : const Icon(Icons.watch, size: 24),
                  )
                : const Icon(Icons.watch_outlined, size: 24, color: Colors.grey),
          ),
        );
      },
    );
  }

  void _showSlotActions(BuildContext context, MixMatchProvider provider, String category) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.swap_horiz),
              title: const Text('Replace'),
              onTap: () {
                Navigator.pop(context);
                provider.setLibraryCategory(category);
              },
            ),
            ListTile(
              leading: const Icon(Icons.clear),
              title: const Text('Remove'),
              onTap: () {
                provider.unequipCategory(category);
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategorySelector(BuildContext context, MixMatchProvider provider) {
    final categories = ['All', 'tops', 'bottoms', 'outerwear', 'shoes', 'accessories'];

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: categories.map((category) {
            final isSelected = (category == 'All' && provider.selectedLibraryCategory == null) ||
                (category != 'All' && provider.selectedLibraryCategory == category);

            return Padding(
              padding: const EdgeInsets.only(right: 8),
              child: ChoiceChip(
                label: Text(category == 'All' ? 'All' : category.toUpperCase()),
                selected: isSelected,
                onSelected: (selected) {
                  provider.setLibraryCategory(selected && category != 'All' ? category : null);
                },
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildItemLibrary(BuildContext context, MixMatchProvider provider) {
    final items = provider.libraryItems;

    if (items.isEmpty) {
      return Center(
        child: Text(
          'No items in this category',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Colors.grey),
        ),
      );
    }

    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 0.75,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        return _buildDraggableItem(context, item);
      },
    );
  }

  Widget _buildDraggableItem(BuildContext context, OutfitItem item) {
    return LongPressDraggable<OutfitItem>(
      data: item,
      feedback: Material(
        elevation: 8,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          width: 80,
          height: 100,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            color: Colors.white,
          ),
          child: item.imageUrl != null
              ? ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.network(
                    item.imageUrl!,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const Icon(Icons.checkroom, size: 40),
                  ),
                )
              : const Icon(Icons.checkroom, size: 40),
        ),
      ),
      childWhenDragging: Opacity(
        opacity: 0.3,
        child: _buildItemCard(context, item),
      ),
      child: _buildItemCard(context, item),
    );
  }

  Widget _buildItemCard(BuildContext context, OutfitItem item) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Theme.of(context).colorScheme.surfaceVariant,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                color: Colors.grey[200],
              ),
              child: item.imageUrl != null
                  ? ClipRRect(
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                      child: Image.network(
                        item.imageUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const Icon(Icons.checkroom, size: 32),
                      ),
                    )
                  : const Center(child: Icon(Icons.checkroom, size: 32)),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.name,
                  style: Theme.of(context).textTheme.bodySmall,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Container(
                      width: 10,
                      height: 10,
                      decoration: BoxDecoration(
                        color: _getColorFromName(item.color),
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.grey[400]!),
                      ),
                    ),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        item.category.toUpperCase(),
                        style: Theme.of(context).textTheme.labelSmall?.copyWith(
                              color: Colors.grey[600],
                            ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getColorFromName(String colorName) {
    final colors = {
      'black': Colors.black,
      'white': Colors.white,
      'red': Colors.red,
      'blue': Colors.blue,
      'navy': Colors.blue[900]!,
      'green': Colors.green,
      'yellow': Colors.yellow,
      'beige': Colors.brown[200]!,
      'brown': Colors.brown,
      'grey': Colors.grey,
      'gray': Colors.grey,
      'pink': Colors.pink,
      'purple': Colors.purple,
      'orange': Colors.orange,
    };

    return colors[colorName.toLowerCase()] ?? Colors.grey;
  }
}
