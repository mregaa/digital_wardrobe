import 'package:flutter/foundation.dart';
import '../../../wardrobe/domain/entities/outfit_item.dart';
import '../../../wardrobe/domain/repositories/mix_match_repository.dart';
import '../../../wardrobe/domain/repositories/wardrobe_repository.dart';

/// Provider for Avatar Outfit Builder (Mix & Match)
class MixMatchProvider with ChangeNotifier {
  final MixMatchRepository mixMatchRepository;
  final WardrobeRepository wardrobeRepository;

  MixMatchProvider({
    required MixMatchRepository repository,
    required this.wardrobeRepository,
  }) : mixMatchRepository = repository;

  // All available outfits from wardrobe
  List<OutfitItem> _allOutfits = [];
  bool _isLoading = false;
  String? _errorMessage;

  // Equipped items by category
  final Map<String, OutfitItem?> _equippedItems = {
    'tops': null,
    'bottoms': null,
    'outerwear': null,
    'shoes': null,
    'accessories': null,
  };

  // Library view
  String? _selectedLibraryCategory; // null = "All"
  
  // Saved combos
  final List<SavedCombo> _savedCombos = [];

  // Getters
  List<OutfitItem> get allOutfits => _allOutfits;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  Map<String, OutfitItem?> get equippedItems => Map.unmodifiable(_equippedItems);
  String? get selectedLibraryCategory => _selectedLibraryCategory;
  List<SavedCombo> get savedCombos => List.unmodifiable(_savedCombos);

  // Get filtered library items based on selected category
  List<OutfitItem> get libraryItems {
    if (_selectedLibraryCategory == null) {
      return _allOutfits;
    }
    return _allOutfits
        .where((item) => item.category.toLowerCase() == _selectedLibraryCategory!.toLowerCase())
        .toList();
  }

  // Get equipped item by category
  OutfitItem? getEquippedItem(String category) {
    return _equippedItems[category.toLowerCase()];
  }

  // Check if any items are equipped
  bool get hasEquippedItems {
    return _equippedItems.values.any((item) => item != null);
  }

  // Get compatibility hint based on equipped items
  String get styleHint {
    final equipped = _equippedItems.values.whereType<OutfitItem>().toList();
    
    if (equipped.length < 2) {
      return 'Add more items to see style hints';
    }

    // Check for monochrome (2+ items same color)
    final colors = equipped.map((item) => item.color.toLowerCase()).toList();
    final colorCounts = <String, int>{};
    for (final color in colors) {
      colorCounts[color] = (colorCounts[color] ?? 0) + 1;
    }
    
    if (colorCounts.values.any((count) => count >= 2)) {
      final monochromeColor = colorCounts.entries
          .firstWhere((entry) => entry.value >= 2)
          .key;
      return '✨ Monochrome $monochromeColor look - sleek and cohesive!';
    }

    // Check for patterns
    final patternCount = equipped.where((item) => 
        item.name.toLowerCase().contains('pattern') ||
        item.name.toLowerCase().contains('stripe') ||
        item.name.toLowerCase().contains('print')
    ).length;
    
    if (patternCount >= 2) {
      return '⚠️ Multiple patterns - consider simplifying';
    } else if (patternCount == 1) {
      return '✨ Perfect! One statement pattern piece';
    }

    // Check for neutral combinations
    final neutrals = ['black', 'white', 'grey', 'gray', 'beige', 'navy'];
    if (colors.every((color) => neutrals.contains(color))) {
      return '🖤 Classic neutral palette - timeless style';
    }

    return '✅ Balanced combination - looks great!';
  }

  /// Load all outfits
  Future<void> loadOutfits() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _allOutfits = await wardrobeRepository.listOutfits();
      print('✅ [MIX_MATCH] Loaded ${_allOutfits.length} outfits');
    } catch (e) {
      _errorMessage = e.toString();
      print('❌ [MIX_MATCH] Error: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Set library category filter
  void setLibraryCategory(String? category) {
    _selectedLibraryCategory = category;
    notifyListeners();
  }

  /// Equip an item to a slot
  void equipItem(OutfitItem item) {
    final category = item.category.toLowerCase();
    if (_equippedItems.containsKey(category)) {
      _equippedItems[category] = item;
      notifyListeners();
      print('✅ [MIX_MATCH] Equipped ${item.name} to $category slot');
    } else {
      print('⚠️ [MIX_MATCH] Unknown category: $category');
    }
  }

  /// Unequip an item from a slot
  void unequipCategory(String category) {
    _equippedItems[category.toLowerCase()] = null;
    notifyListeners();
    print('🗑️ [MIX_MATCH] Unequipped $category slot');
  }

  /// Clear all equipped items
  void clearAll() {
    for (final key in _equippedItems.keys) {
      _equippedItems[key] = null;
    }
    notifyListeners();
    print('🗑️ [MIX_MATCH] Cleared all slots');
  }

  /// Save current combination
  void saveCombo(String name) {
    if (!hasEquippedItems) {
      print('⚠️ [MIX_MATCH] Cannot save empty combo');
      return;
    }

    final combo = SavedCombo(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
      equippedItems: Map.from(_equippedItems),
      savedAt: DateTime.now(),
    );
    
    _savedCombos.add(combo);
    notifyListeners();
    print('💾 [MIX_MATCH] Saved combo: $name');
  }

  /// Load a saved combination
  void loadCombo(SavedCombo combo) {
    for (final entry in combo.equippedItems.entries) {
      _equippedItems[entry.key] = entry.value;
    }
    notifyListeners();
    print('📂 [MIX_MATCH] Loaded combo: ${combo.name}');
  }

  /// Delete a saved combination
  void deleteCombo(String comboId) {
    _savedCombos.removeWhere((combo) => combo.id == comboId);
    notifyListeners();
    print('🗑️ [MIX_MATCH] Deleted combo: $comboId');
  }
}

/// Model for saved combinations
class SavedCombo {
  final String id;
  final String name;
  final Map<String, OutfitItem?> equippedItems;
  final DateTime savedAt;

  SavedCombo({
    required this.id,
    required this.name,
    required this.equippedItems,
    required this.savedAt,
  });
}
