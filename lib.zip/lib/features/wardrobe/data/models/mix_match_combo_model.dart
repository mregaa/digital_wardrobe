import 'package:json_annotation/json_annotation.dart';
import '../../domain/entities/mix_match_combo.dart';

part 'mix_match_combo_model.g.dart';

@JsonSerializable()
class MixMatchComboModel extends MixMatchCombo {
  const MixMatchComboModel({
    required super.id,
    required super.name,
    required super.topId,
    super.topImageUrl,
    super.topName,
    required super.bottomId,
    super.bottomImageUrl,
    super.bottomName,
    super.compatibilityNote,
    required super.createdAt,
    super.updatedAt,
  });

  factory MixMatchComboModel.fromJson(Map<String, dynamic> json) =>
      _$MixMatchComboModelFromJson(json);

  Map<String, dynamic> toJson() => _$MixMatchComboModelToJson(this);

  factory MixMatchComboModel.fromEntity(MixMatchCombo combo) {
    return MixMatchComboModel(
      id: combo.id,
      name: combo.name,
      topId: combo.topId,
      topImageUrl: combo.topImageUrl,
      topName: combo.topName,
      bottomId: combo.bottomId,
      bottomImageUrl: combo.bottomImageUrl,
      bottomName: combo.bottomName,
      compatibilityNote: combo.compatibilityNote,
      createdAt: combo.createdAt,
      updatedAt: combo.updatedAt,
    );
  }

  MixMatchCombo toEntity() {
    return MixMatchCombo(
      id: id,
      name: name,
      topId: topId,
      topImageUrl: topImageUrl,
      topName: topName,
      bottomId: bottomId,
      bottomImageUrl: bottomImageUrl,
      bottomName: bottomName,
      compatibilityNote: compatibilityNote,
      createdAt: createdAt,
      updatedAt: updatedAt,
    );
  }

  MixMatchComboModel copyWithModel({
    String? id,
    String? name,
    String? topId,
    String? topImageUrl,
    String? topName,
    String? bottomId,
    String? bottomImageUrl,
    String? bottomName,
    String? compatibilityNote,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return MixMatchComboModel(
      id: id ?? this.id,
      name: name ?? this.name,
      topId: topId ?? this.topId,
      topImageUrl: topImageUrl ?? this.topImageUrl,
      topName: topName ?? this.topName,
      bottomId: bottomId ?? this.bottomId,
      bottomImageUrl: bottomImageUrl ?? this.bottomImageUrl,
      bottomName: bottomName ?? this.bottomName,
      compatibilityNote: compatibilityNote ?? this.compatibilityNote,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
