// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'mix_match_combo_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

MixMatchComboModel _$MixMatchComboModelFromJson(Map<String, dynamic> json) =>
    MixMatchComboModel(
      id: json['id'] as String,
      name: json['name'] as String,
      topId: json['topId'] as String,
      topImageUrl: json['topImageUrl'] as String?,
      topName: json['topName'] as String?,
      bottomId: json['bottomId'] as String,
      bottomImageUrl: json['bottomImageUrl'] as String?,
      bottomName: json['bottomName'] as String?,
      compatibilityNote: json['compatibilityNote'] as String?,
      createdAt: DateTime.parse(json['createdAt'] as String),
      updatedAt: json['updatedAt'] == null
          ? null
          : DateTime.parse(json['updatedAt'] as String),
    );

Map<String, dynamic> _$MixMatchComboModelToJson(MixMatchComboModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'topId': instance.topId,
      'topImageUrl': instance.topImageUrl,
      'topName': instance.topName,
      'bottomId': instance.bottomId,
      'bottomImageUrl': instance.bottomImageUrl,
      'bottomName': instance.bottomName,
      'compatibilityNote': instance.compatibilityNote,
      'createdAt': instance.createdAt.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
    };
