import 'package:json_annotation/json_annotation.dart';
import '../../domain/entities/outfit_item.dart';

part 'outfit_model.g.dart';

@JsonSerializable()
class OutfitModel extends OutfitItem {
  const OutfitModel({
    required super.id,
    required super.name,
    required super.category,
    required super.color,
    super.notes,
    super.imageUrl,
    super.isFavorite,
    required super.userId,
    required super.createdAt,
    super.updatedAt,
  });

  factory OutfitModel.fromJson(Map<String, dynamic> json) {
    // Handle flexible date parsing
    DateTime parseDateTime(dynamic value) {
      if (value == null) throw FormatException('DateTime cannot be null');
      if (value is DateTime) return value;
      if (value is String) return DateTime.parse(value);
      throw FormatException('Invalid DateTime format: $value');
    }

    DateTime? parseOptionalDateTime(dynamic value) {
      if (value == null) return null;
      if (value is DateTime) return value;
      if (value is String) return DateTime.parse(value);
      return null;
    }

    return OutfitModel(
      id: json['id'] as String,
      name: json['name'] as String,
      category: json['category'] as String,
      color: json['color'] as String? ?? '',
      notes: json['notes'] as String?,
      imageUrl: json['imageUrl'] as String?,
      isFavorite: json['isFavorite'] as bool? ?? false,
      userId: json['userId'] as String,
      createdAt: parseDateTime(json['createdAt']),
      updatedAt: parseOptionalDateTime(json['updatedAt']),
    );
  }

  Map<String, dynamic> toJson() => _$OutfitModelToJson(this);

  factory OutfitModel.fromEntity(OutfitItem outfit) {
    return OutfitModel(
      id: outfit.id,
      name: outfit.name,
      category: outfit.category,
      color: outfit.color,
      notes: outfit.notes,
      imageUrl: outfit.imageUrl,
      isFavorite: outfit.isFavorite,
      userId: outfit.userId,
      createdAt: outfit.createdAt,
      updatedAt: outfit.updatedAt,
    );
  }

  OutfitItem toEntity() {
    return OutfitItem(
      id: id,
      name: name,
      category: category,
      color: color,
      notes: notes,
      imageUrl: imageUrl,
      isFavorite: isFavorite,
      userId: userId,
      createdAt: createdAt,
      updatedAt: updatedAt,
    );
  }

  OutfitModel copyWithModel({
    String? id,
    String? name,
    String? category,
    String? color,
    String? notes,
    String? imageUrl,
    bool? isFavorite,
    String? userId,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return OutfitModel(
      id: id ?? this.id,
      name: name ?? this.name,
      category: category ?? this.category,
      color: color ?? this.color,
      notes: notes ?? this.notes,
      imageUrl: imageUrl ?? this.imageUrl,
      isFavorite: isFavorite ?? this.isFavorite,
      userId: userId ?? this.userId,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
