// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'outfit_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OutfitModel _$OutfitModelFromJson(Map<String, dynamic> json) => OutfitModel(
  id: json['id'] as String,
  name: json['name'] as String,
  category: json['category'] as String,
  color: json['color'] as String,
  notes: json['notes'] as String?,
  imageUrl: json['imageUrl'] as String?,
  isFavorite: json['isFavorite'] as bool? ?? false,
  userId: json['userId'] as String,
  createdAt: DateTime.parse(json['createdAt'] as String),
  updatedAt: json['updatedAt'] == null
      ? null
      : DateTime.parse(json['updatedAt'] as String),
);

Map<String, dynamic> _$OutfitModelToJson(OutfitModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'category': instance.category,
      'color': instance.color,
      'notes': instance.notes,
      'imageUrl': instance.imageUrl,
      'isFavorite': instance.isFavorite,
      'userId': instance.userId,
      'createdAt': instance.createdAt.toIso8601String(),
      'updatedAt': instance.updatedAt?.toIso8601String(),
    };
