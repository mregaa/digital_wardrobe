import 'package:flutter/foundation.dart';
import '../../domain/entities/outfit_item.dart';
import '../../domain/entities/mix_match_combo.dart';
import '../../domain/repositories/mix_match_repository.dart';

/// Provider for Mix & Match feature
class MixMatchProvider with ChangeNotifier {
  final MixMatchRepository repository;

  MixMatchProvider({required this.repository});

  List<OutfitItem> _tops = [];
  List<OutfitItem> _bottoms = [];
  List<MixMatchCombo> _savedCombos = [];
  
  OutfitItem? _selectedTop;
  OutfitItem? _selectedBottom;
  
  bool _isLoading = false;
  String? _errorMessage;

  List<OutfitItem> get tops => _tops;
  List<OutfitItem> get bottoms => _bottoms;
  List<MixMatchCombo> get savedCombos => _savedCombos;
  
  OutfitItem? get selectedTop => _selectedTop;
  OutfitItem? get selectedBottom => _selectedBottom;
  
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  bool get hasSelection => _selectedTop != null && _selectedBottom != null;
  
  /// Get compatibility score for current selection
  String get compatibilityScore {
    if (_selectedTop == null || _selectedBottom == null) return '';
    return repository.calculateCompatibility(_selectedTop!, _selectedBottom!);
  }

  /// Load tops
  Future<void> loadTops() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _tops = await repository.listTops();
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Load bottoms
  Future<void> loadBottoms() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      _bottoms = await repository.listBottoms();
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Load both tops and bottoms
  Future<void> loadAllItems() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();

    try {
      await Future.wait([
        repository.listTops().then((items) => _tops = items),
        repository.listBottoms().then((items) => _bottoms = items),
      ]);
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Load saved combos
  Future<void> loadSavedCombos() async {
    try {
      _savedCombos = await repository.listSavedCombos();
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  /// Select top
  void selectTop(OutfitItem? top) {
    _selectedTop = top;
    notifyListeners();
  }

  /// Select bottom
  void selectBottom(OutfitItem? bottom) {
    _selectedBottom = bottom;
    notifyListeners();
  }

  /// Clear selection
  void clearSelection() {
    _selectedTop = null;
    _selectedBottom = null;
    notifyListeners();
  }

  /// Save current combination
  Future<bool> saveCurrentCombo({String? comboName, String? notes}) async {
    if (_selectedTop == null || _selectedBottom == null) {
      _errorMessage = 'Please select both top and bottom';
      notifyListeners();
      return false;
    }

    try {
      final combo = await repository.saveCombo(
        name: comboName ?? 'Combo ${_savedCombos.length + 1}',
        topId: _selectedTop!.id,
        bottomId: _selectedBottom!.id,
        compatibilityNote: notes,
      );
      
      _savedCombos.add(combo);
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  /// Delete saved combo
  Future<bool> deleteSavedCombo(String comboId) async {
    try {
      await repository.deleteSavedCombo(comboId);
      _savedCombos.removeWhere((c) => c.id == comboId);
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
      return false;
    }
  }

  /// Load combo into selection
  void loadCombo(MixMatchCombo combo) {
    // Find matching items
    _selectedTop = _tops.firstWhere(
      (t) => t.id == combo.topId,
      orElse: () => OutfitItem(
        id: combo.topId,
        name: 'Top',
        category: 'tops',
        color: '',
        userId: '',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ),
    );
    
    _selectedBottom = _bottoms.firstWhere(
      (b) => b.id == combo.bottomId,
      orElse: () => OutfitItem(
        id: combo.bottomId,
        name: 'Bottom',
        category: 'bottoms',
        color: '',
        userId: '',
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ),
    );
    
    notifyListeners();
  }

  /// Clear error
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
